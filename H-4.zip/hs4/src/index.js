import React from 'react'
import ReactDOM from 'react-dom'
import {} from 'redux';
import { Provider } from 'react-redux';
import {} from 'redux-form'
import App from './App'
import './App.css';
import store from './store';
ReactDOM.render( <
    Provider store = { store } >
    <
    App / >
    <
    /Provider>, document.getElementById('root')
);