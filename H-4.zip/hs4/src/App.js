import React from 'react';
import showResults from './showResults';
import SyncValidationForm from './SyncValidationForm';
function App()
{
  
   
    return (
      <div className="container">
        <br></br>
        <h1>Form Validation <span style={{ color: "red" }}>*</span></h1>
        <SyncValidationForm onSubmit={showResults} />
      </div>
    )
  }
export default App;

